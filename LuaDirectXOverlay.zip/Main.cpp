//*********************************************************
//
// Copyright (c) Microsoft. All rights reserved.
// This code is licensed under the MIT License (MIT).
// THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
// IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
// PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//*********************************************************

#include <stdio.h>
#include "stdafx.h"
#include "lua.hpp"
#include "DirectCompositeSample.h"

//static void close_state(lua_State** L) { lua_close(*L); }
//#define cleanup(x) __attribute__((cleanup(x)))
//#define auto_lclose cleanup(close_state) 

//bool CheckLua(lua_State* L, int r) {
//    if (r != LUA_OK) {
//        std::string errmsg = lua_tostring(L, -1);
//        return false;
//    }
//    return true;
//}

_Use_decl_annotations_
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow)
{
    //Create VM state
    lua_State* L = luaL_newstate();
    //run config
    //WCHAR path[MAX_PATH];
    //GetModuleFileName(NULL, path, MAX_PATH);
    int Rcfg = luaL_dofile(L, "cfg.lua");
    if (!L)
        return 1;
    luaL_openlibs(L); // Open standard libraries

	DirectCompositeSample sample(512, 512, L"Lua Overlay");
    int wnderr = Win32Application::Run(&sample, hInstance, nCmdShow);
    lua_close(L); //close lua state
    return wnderr;
}
